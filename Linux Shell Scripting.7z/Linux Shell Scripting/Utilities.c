#include "Utilities.h"

char* read_line(FILE* location) {

    char* line = NULL;
    size_t aux = 0;

    if ( getline(&line, &aux, location) == -1 )
      exit(EXIT_SUCCESS);
    // getline(&line, &aux, location);
    return line;
}

char** split_line(char *line) {

    int maxElements = 32, position = 0;

    char** array = malloc(maxElements * sizeof(char*));

    if (!array) {
        fprintf(stderr, "[Error] Bad alloc of array! \n");
        exit(EXIT_FAILURE);
    }

    char* element = strtok(line, " \t\r\n\a");
    while (element != NULL) {
        array[position] = element;
        position++;

        //Daca am trecut de limita de elemente, marim limita cu 32 si realocam spatiul
        if (position >= maxElements) {
            maxElements += 32;
            array = realloc(array, maxElements * sizeof(char*));

            if (!array) {
                fprintf(stderr, "[Error] Bad realloc of array! \n");
                exit(EXIT_FAILURE);
            }
        }

        //Continuam cu tokul
        element = strtok(NULL, " \t\r\n\a");
    }

    //Punem pe ultima pozitie un terminator-null
    array[position] = NULL;

    return array;
}

int num_args(char** args) {

    int nrcom = 0;
    char* elem = args[0];
    while(elem != NULL) nrcom++, elem = args[nrcom];

    return nrcom;
}
